# Leitner System

[What is this?](https://en.wikipedia.org/wiki/Leitner_system) This is a CLI app to present flashcards
Code is very basic, and uses nothing special.
